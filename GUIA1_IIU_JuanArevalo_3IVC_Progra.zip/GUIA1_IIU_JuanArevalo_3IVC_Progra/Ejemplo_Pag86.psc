Algoritmo Ejemplo_Pag86
	Definir num Como Entero
	
	Escribir "Introduzca un n�mero:"
	Leer num
	
	Si num < 0 Entonces
		Escribir "El n�mero es menor a cero"
	SiNo
		Escribir "El n�mero es igual o mayor a cero"
	FinSi
FinAlgoritmo
