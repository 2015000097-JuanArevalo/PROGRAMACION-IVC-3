Proceso Act2_Lecc20_Inc1
    Definir password Como Cadena

    Escribir Sin Saltar "Ingrese su contrase�a: "
    Leer password

    Si password = "Password123" Entonces
        Escribir "Bienvenido"
    Sino
        Escribir "Acceso denegado"
    FinSi
FinProceso
